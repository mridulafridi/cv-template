setInterval(myFunction, 1000);

function myFunction() {
	let d = new Date();
	document.getElementById('timer').innerHTML=
	d.getHours() + ":" +
	d.getMinutes() + ":" +
	d.getSeconds();
}

if (time < 20) {
  greeting = "Good day";
} else {
  greeting = "Good evening"; 
}

